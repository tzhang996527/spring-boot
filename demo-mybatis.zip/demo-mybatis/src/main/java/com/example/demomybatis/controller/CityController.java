package com.example.demomybatis.controller;

import com.example.demomybatis.dao.CityDao;
import com.example.demomybatis.entity.City;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("api/v1/city")
public class CityController {

    private final CityDao cityDao;

    @Autowired
    public CityController(CityDao cityDao){
        this.cityDao = cityDao;
    }

    @GetMapping
    public List<City> getAllCities(){
        return this.cityDao.getAllCities();
    }
}
