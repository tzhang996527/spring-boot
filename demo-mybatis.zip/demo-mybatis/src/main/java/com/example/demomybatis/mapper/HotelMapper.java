package com.example.demomybatis.mapper;

import com.example.demomybatis.entity.City;
import com.example.demomybatis.entity.Hotel;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface HotelMapper {
    @Select("select * from hotel where city = #{id}")
    Hotel selectByCityId(int cityId);

    @Insert("INSERT INTO hotel (city, name, address,zip) " +
            "VALUES(#{city}, #{name}, #{address}, #{zip})")
    void insert(Hotel hotel);
}
